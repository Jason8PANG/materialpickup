# -*- coding: utf-8 -*-
"""
测试 F-002: 看板主页

覆盖 TC-F002-001 ~ TC-F002-007
"""


class TestKanban:
    """看板主页测试"""

    def test_kanban_as_requester(self, client, mock_db, login_as_requester):
        """TC-F002-001: 领料员视角看板"""
        resp = client.get('/api/kanban/cards')
        data = resp.get_json()
        assert resp.status_code == 200
        assert data['success'] is True

        groups = data['groups']
        # 验证 5 列都存在
        for status in ['pending_approval', 'pending_prep', 'prepping', 'short', 'ready_pickup']:
            assert status in groups, f"缺少状态列: {status}"
            assert 'title' in groups[status]
            assert 'cards' in groups[status]
            assert 'count' in groups[status]

        # 验证状态顺序
        assert data['status_order'] == [
            'pending_approval', 'pending_prep', 'prepping', 'short', 'ready_pickup'
        ]

        # 验证已完成/已驳回/已删除不显示
        all_cards = []
        for g in groups.values():
            all_cards.extend(g['cards'])
        card_ids = [c['id'] for c in all_cards]
        assert 6 not in card_ids, "已完成单据(id=6)不应显示在看板中"
        assert 7 not in card_ids, "已驳回单据(id=7)不应显示在看板中"
        assert 8 not in card_ids, "已删除单据(id=8)不应显示在看板中"

    def test_kanban_as_supervisor(self, client, mock_db, login_as_supervisor):
        """TC-F002-002: 主管视角看板"""
        resp = client.get('/api/kanban/cards')
        data = resp.get_json()
        assert resp.status_code == 200

        pending_approval_cards = data['groups']['pending_approval']['cards']
        for card in pending_approval_cards:
            assert 'approve' in card['actions']
            assert 'reject' in card['actions']

    def test_kanban_as_warehouse(self, client, mock_db, login_as_warehouse):
        """TC-F002-003: 仓库视角看板"""
        resp = client.get('/api/kanban/cards')
        data = resp.get_json()
        assert resp.status_code == 200

        pending_prep_cards = data['groups']['pending_prep']['cards']
        for card in pending_prep_cards:
            assert 'assign_worker' in card['actions']
            assert 'start_prep' in card['actions']

        prepping_cards = data['groups']['prepping']['cards']
        for card in prepping_cards:
            assert 'complete_prep' in card['actions']
            assert 'short' in card['actions']

    def test_kanban_as_admin(self, client, mock_db, login_as_admin):
        """TC-F002-004: 管理员视角看板"""
        resp = client.get('/api/kanban/cards')
        data = resp.get_json()
        assert resp.status_code == 200

        all_actions = ['approve', 'reject', 'assign_worker', 'start_prep',
                       'complete_prep', 'short', 'sign']
        for group_key, group in data['groups'].items():
            for card in group['cards']:
                for action in all_actions:
                    assert action in card['actions'], \
                        f"管理员应拥有 {action} 权限，但卡片 {card['id']} 在 {group_key} 列中没有"

    def test_kanban_not_logged_in(self, client, mock_db):
        """TC-F002-005: 未登录访问看板"""
        resp = client.get('/api/kanban/cards')
        data = resp.get_json()
        assert resp.status_code == 401
        assert data['success'] is False
        assert '未登录' in data['message']

    def test_kanban_page_route(self, client, mock_db, login_as_requester):
        """TC-F002-007: 页面路由访问看板页"""
        resp = client.get('/kanban')
        assert resp.status_code == 200
