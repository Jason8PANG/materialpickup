# -*- coding: utf-8 -*-
"""
测试 F-006: 仓库查询未完成单据
测试 F-007: 仓库备料状态更新
测试 F-008: 缺料登记反馈
测试 F-009: 取料签字确认

覆盖 TC-F006-001 ~ TC-F006-006, TC-F007-001 ~ TC-F007-008,
      TC-F008-001 ~ TC-F008-004, TC-F009-001 ~ TC-F009-004
"""


class TestWarehousePending:
    """未完成单据查询测试 (F-006)"""

    def test_pending_list(self, client, mock_db, login_as_warehouse):
        """TC-F006-001: 仓库查询所有未完成单据"""
        resp = client.get('/api/requests/pending')
        data = resp.get_json()
        assert resp.status_code == 200
        assert data['success'] is True
        assert 'data' in data
        assert 'total' in data
        assert 'page' in data
        assert data['page'] == 1

    def test_pending_filter_by_job_order(self, client, mock_db, login_as_warehouse):
        """TC-F006-002: 按工单号筛选"""
        resp = client.get('/api/requests/pending?job_order=WO-2024-001')
        data = resp.get_json()
        assert resp.status_code == 200
        assert data['success'] is True

    def test_pending_filter_by_status(self, client, mock_db, login_as_warehouse):
        """TC-F006-003: 按状态筛选"""
        resp = client.get('/api/requests/pending?status=prepping')
        data = resp.get_json()
        assert resp.status_code == 200
        assert data['success'] is True

    def test_pending_pagination(self, client, mock_db, login_as_warehouse):
        """TC-F006-004: 分页查询"""
        resp = client.get('/api/requests/pending?page=1&size=2')
        data = resp.get_json()
        assert resp.status_code == 200
        assert data['page'] == 1
        assert data['size'] == 2

    def test_pending_page_route(self, client, mock_db, login_as_warehouse):
        """TC-F006-005: 未完成单据页面路由"""
        resp = client.get('/pending')
        assert resp.status_code == 200

    def test_pending_page_forbidden(self, client, mock_db, login_as_requester):
        """TC-F006-006: 领料员不能访问未完成单据页面"""
        resp = client.get('/pending')
        assert resp.status_code == 403
        assert '权限不足' in resp.data.decode()


class TestWarehousePrep:
    """仓库备料状态更新测试 (F-007)"""

    def test_start_prep_success(self, client, mock_db, login_as_warehouse):
        """TC-F007-001: 开始备料"""
        resp = client.post('/api/requests/2/start-prep')
        data = resp.get_json()
        assert resp.status_code == 200
        assert data['success'] is True
        assert '开始备料' in data['message']

    def test_complete_prep_success(self, client, mock_db, login_as_warehouse):
        """TC-F007-002: 完成备料"""
        resp = client.post('/api/requests/3/complete-prep')
        data = resp.get_json()
        assert resp.status_code == 200
        assert data['success'] is True
        assert '备料完成' in data['message']

    def test_start_prep_wrong_status(self, client, mock_db, login_as_warehouse):
        """TC-F007-003: 对非待备料状态执行开始备料"""
        resp = client.post('/api/requests/3/start-prep')  # id=3 状态是 prepping
        data = resp.get_json()
        assert resp.status_code == 400
        assert data['success'] is False
        assert '当前状态不允许开始备料' in data['message']

    def test_complete_prep_wrong_status(self, client, mock_db, login_as_warehouse):
        """TC-F007-004: 对非备料中状态执行完成备料"""
        resp = client.post('/api/requests/2/complete-prep')  # id=2 状态是 pending_prep
        data = resp.get_json()
        assert resp.status_code == 400
        assert data['success'] is False
        assert '当前状态不允许完成备料' in data['message']

    def test_start_prep_wrong_role(self, client, mock_db, login_as_requester):
        """TC-F007-005: 非仓库角色尝试备料"""
        resp = client.post('/api/requests/2/start-prep')
        data = resp.get_json()
        assert resp.status_code == 403
        assert data['success'] is False
        assert '权限不足' in data['message']

    def test_assign_worker_success(self, client, mock_db, login_as_warehouse):
        """TC-F007-006: 指定备料员"""
        resp = client.put('/api/requests/2/assign-worker', json={
            'warehouse_operator': 'warehouse2'
        })
        data = resp.get_json()
        assert resp.status_code == 200
        assert data['success'] is True
        assert '已指定备料员' in data['message']

    def test_assign_worker_missing(self, client, mock_db, login_as_warehouse):
        """TC-F007-008: 指定备料员时不填备料员"""
        resp = client.put('/api/requests/2/assign-worker', json={})
        data = resp.get_json()
        assert resp.status_code == 400
        assert data['success'] is False
        assert '请指定备料员' in data['message']

    def test_assign_worker_non_pending(self, client, mock_db, login_as_warehouse):
        """在非待备料/备料中状态指定备料员"""
        resp = client.put('/api/requests/1/assign-worker', json={
            'warehouse_operator': 'warehouse2'
        })
        data = resp.get_json()
        assert resp.status_code == 400
        assert data['success'] is False


class TestWarehouseShort:
    """缺料登记测试 (F-008)"""

    def test_short_prepping(self, client, mock_db, login_as_warehouse):
        """TC-F008-001: 备料中缺料登记"""
        resp = client.post('/api/requests/3/short', json={
            'short_reason': '库存不足，需等待采购到货'
        })
        data = resp.get_json()
        assert resp.status_code == 200
        assert data['success'] is True
        assert '缺料登记成功' in data['message']

    def test_short_missing_reason(self, client, mock_db, login_as_warehouse):
        """TC-F008-002: 缺料登记时未填写原因"""
        resp = client.post('/api/requests/3/short', json={
            'short_reason': ''
        })
        data = resp.get_json()
        assert resp.status_code == 400
        assert data['success'] is False
        assert '请填写缺料原因' in data['message']

    def test_short_wrong_status(self, client, mock_db, login_as_warehouse):
        """TC-F008-003: 对非备料中/待备料状态的单据登记缺料"""
        resp = client.post('/api/requests/1/short', json={
            'short_reason': '缺料'
        })
        data = resp.get_json()
        assert resp.status_code == 400
        assert data['success'] is False
        assert '当前状态不允许登记缺料' in data['message']

    def test_short_pending_prep(self, client, mock_db, login_as_warehouse):
        """TC-F008-004: 待备料状态登记缺料"""
        resp = client.post('/api/requests/2/short', json={
            'short_reason': '物料停产物料'
        })
        data = resp.get_json()
        assert resp.status_code == 200
        assert data['success'] is True


class TestWarehouseSign:
    """签字确认测试 (F-009)"""

    def test_sign_ready_pickup(self, client, mock_db, login_as_warehouse):
        """TC-F009-001: 待取料签字确认"""
        resp = client.post('/api/requests/5/sign')
        data = resp.get_json()
        assert resp.status_code == 200
        assert data['success'] is True
        assert '签字确认成功' in data['message']

    def test_sign_short_status(self, client, mock_db, login_as_warehouse):
        """TC-F009-002: 缺料状态签字确认"""
        resp = client.post('/api/requests/4/sign')
        data = resp.get_json()
        assert resp.status_code == 200
        assert data['success'] is True

    def test_sign_wrong_status(self, client, mock_db, login_as_warehouse):
        """TC-F009-003: 对待审批状态执行签字"""
        resp = client.post('/api/requests/1/sign')
        data = resp.get_json()
        assert resp.status_code == 400
        assert data['success'] is False
        assert '当前状态不允许签字确认' in data['message']

    def test_sign_wrong_role(self, client, mock_db, login_as_supervisor):
        """非仓库/领料员/管理员角色尝试签字"""
        resp = client.post('/api/requests/5/sign')
        data = resp.get_json()
        assert resp.status_code == 403
        assert data['success'] is False
