# -*- coding: utf-8 -*-
"""
测试 F-010: 账号-角色映射管理

覆盖 TC-F010-001 ~ TC-F010-010
"""


class TestRoleMapping:
    """账号角色映射测试"""

    def test_list_mappings(self, client, mock_db, login_as_admin):
        """TC-F010-001: 管理员查询所有角色映射"""
        resp = client.get('/api/role-mappings')
        data = resp.get_json()
        assert resp.status_code == 200
        assert data['success'] is True
        assert 'data' in data

    def test_create_mapping(self, client, mock_db, login_as_admin):
        """TC-F010-002: 管理员新增角色映射"""
        resp = client.post('/api/role-mappings', json={
            'domain_account': 'new_user',
            'display_name': '新用户',
            'role': 'requester',
            'email': 'new@test.com',
            'is_active': 1,
            'remark': '新员工'
        })
        data = resp.get_json()
        assert resp.status_code == 201
        assert data['success'] is True
        assert '创建成功' in data['message']

    def test_create_mapping_missing_field(self, client, mock_db, login_as_admin):
        """TC-F010-003: 新增映射缺少必填字段"""
        resp = client.post('/api/role-mappings', json={
            'role': 'requester'
        })
        data = resp.get_json()
        assert resp.status_code == 400
        assert data['success'] is False
        assert 'domain_account' in data['message']

    def test_create_mapping_invalid_role(self, client, mock_db, login_as_admin):
        """TC-F010-004: 新增映射使用无效角色"""
        resp = client.post('/api/role-mappings', json={
            'domain_account': 'test_user',
            'role': 'invalid_role'
        })
        data = resp.get_json()
        assert resp.status_code == 400
        assert data['success'] is False
        assert '无效角色' in data['message']

    def test_update_mapping(self, client, mock_db, login_as_admin):
        """TC-F010-005: 管理员编辑角色映射"""
        resp = client.put('/api/role-mappings/2', json={
            'display_name': '主管张三(已更新)',
            'email': 'newemail@test.com'
        })
        data = resp.get_json()
        assert resp.status_code == 200
        assert data['success'] is True
        assert '更新成功' in data['message']

    def test_update_non_existent_mapping(self, client, mock_db, login_as_admin):
        """TC-F010-006: 编辑不存在的角色映射"""
        resp = client.put('/api/role-mappings/999', json={
            'display_name': '测试'
        })
        data = resp.get_json()
        assert resp.status_code == 404
        assert data['success'] is False
        assert '记录不存在' in data['message']

    def test_delete_mapping(self, client, mock_db, login_as_admin):
        """TC-F010-007: 管理员删除角色映射"""
        resp = client.delete('/api/role-mappings/3')
        data = resp.get_json()
        assert resp.status_code == 200
        assert data['success'] is True
        assert '删除成功' in data['message']

    def test_list_mappings_wrong_role(self, client, mock_db, login_as_supervisor):
        """TC-F010-008: 非管理员访问映射管理"""
        resp = client.get('/api/role-mappings')
        data = resp.get_json()
        assert resp.status_code == 403
        assert data['success'] is False
        assert '权限不足' in data['message']

    def test_admin_mappings_page_route(self, client, mock_db, login_as_admin):
        """TC-F010-009: 账号管理页面路由"""
        resp = client.get('/admin/mappings')
        assert resp.status_code == 200

    def test_admin_mappings_page_forbidden(self, client, mock_db, login_as_requester):
        """TC-F010-010: 非管理员访问页面路由"""
        resp = client.get('/admin/mappings')
        assert resp.status_code == 403
        assert '权限不足' in resp.data.decode()
