# -*- coding: utf-8 -*-
"""
测试 F-003: 提交领料申请 与 F-014: 申请单编辑/撤回

覆盖 TC-F003-001 ~ TC-F003-008, TC-F014-001 ~ TC-F014-004
"""


class TestRequestCreate:
    """提交领料申请测试"""

    def test_create_request_success(self, client, mock_db, login_as_requester):
        """TC-F003-001: 领料员提交完整申请单"""
        resp = client.post('/api/requests', json={
            'job_order': 'WO-2024-010',
            'part_number': 'PN-010',
            'quantity': 10,
            'price': 5.5,
            'total_amount': 55,
            'stock_qty': 100,
            'replenish_reason': '报废'
        })
        data = resp.get_json()
        assert resp.status_code == 200
        assert data['success'] is True
        assert data['id'] is not None
        assert '申请提交成功' in data['message']

    def test_create_request_missing_job_order(self, client, mock_db, login_as_requester):
        """TC-F003-002: 缺少必填字段（工单号）"""
        resp = client.post('/api/requests', json={
            'part_number': 'PN-010',
            'quantity': 10
        })
        data = resp.get_json()
        assert resp.status_code == 400
        assert data['success'] is False
        assert 'job_order' in data['message']

    def test_create_request_missing_quantity(self, client, mock_db, login_as_requester):
        """TC-F003-003: 缺少 quantity 字段"""
        resp = client.post('/api/requests', json={
            'job_order': 'WO-001',
            'part_number': 'PN-010'
        })
        data = resp.get_json()
        assert resp.status_code == 400
        assert data['success'] is False
        assert 'quantity' in data['message']

    def test_create_request_wrong_role(self, client, mock_db, login_as_supervisor):
        """TC-F003-004: 非领料员提交申请"""
        resp = client.post('/api/requests', json={
            'job_order': 'WO-001',
            'part_number': 'PN-010',
            'quantity': 10
        })
        data = resp.get_json()
        assert resp.status_code == 403
        assert data['success'] is False
        assert '权限不足' in data['message']

    def test_create_request_with_other_reason(self, client, mock_db, login_as_requester):
        """TC-F003-005: 补料原因为"其他"时填写详细说明"""
        resp = client.post('/api/requests', json={
            'job_order': 'WO-011',
            'part_number': 'PN-011',
            'quantity': 5,
            'replenish_reason': '其他',
            'replenish_reason_other': '紧急补料'
        })
        data = resp.get_json()
        assert resp.status_code == 200
        assert data['success'] is True

    def test_create_request_not_logged_in(self, client, mock_db):
        """TC-F003-006: 未登录提交申请"""
        resp = client.post('/api/requests', json={
            'job_order': 'WO-001',
            'part_number': 'PN-010',
            'quantity': 10
        })
        data = resp.get_json()
        assert resp.status_code == 401
        assert data['success'] is False
        assert '未登录' in data['message']

    def test_request_new_page_route(self, client, mock_db, login_as_requester):
        """TC-F003-007: 新增申请页面路由"""
        resp = client.get('/request/new')
        assert resp.status_code == 200

    def test_request_new_page_forbidden(self, client, mock_db, login_as_warehouse):
        """TC-F003-008: 非领料员访问新增申请页面"""
        resp = client.get('/request/new')
        assert resp.status_code == 403
        assert '权限不足' in resp.data.decode()

    def test_admin_can_create_request(self, client, mock_db, login_as_admin):
        """管理员也可以提交申请（权限矩阵允许）"""
        resp = client.post('/api/requests', json={
            'job_order': 'WO-ADMIN-001',
            'part_number': 'PN-ADMIN',
            'quantity': 1
        })
        data = resp.get_json()
        assert resp.status_code == 200
        assert data['success'] is True


class TestRequestQuery:
    """申请单查询测试 (F-014)"""

    def test_get_request_detail(self, client, mock_db, login_as_requester):
        """TC-F014-001: 查看申请单详情"""
        resp = client.get('/api/requests/1')
        data = resp.get_json()
        assert resp.status_code == 200
        assert data['success'] is True
        assert data['request']['id'] == 1
        assert data['request']['status_label'] == '待审批'
        assert 'logs' in data

    def test_get_non_existent_request(self, client, mock_db, login_as_requester):
        """TC-F014-002: 查询不存在的单据"""
        resp = client.get('/api/requests/999')
        data = resp.get_json()
        assert resp.status_code == 404
        assert data['success'] is False
        assert '单据不存在' in data['message']

    def test_request_detail_page_route(self, client, mock_db, login_as_requester):
        """TC-F014-003: 详情页路由访问"""
        resp = client.get('/request/1')
        assert resp.status_code == 200

    def test_list_requests_with_filter(self, client, mock_db, login_as_requester):
        """TC-F014-004: 列表查询带筛选"""
        resp = client.get('/api/requests?status=pending_approval&page=1&size=20')
        data = resp.get_json()
        assert resp.status_code == 200
        assert data['success'] is True
        assert 'data' in data
        assert 'total' in data
        assert 'page' in data
        assert 'size' in data
        assert data['page'] == 1
        assert data['size'] == 20
