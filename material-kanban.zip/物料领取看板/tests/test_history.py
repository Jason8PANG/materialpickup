# -*- coding: utf-8 -*-
"""
测试 F-011: 历史单据归档查询

覆盖 TC-F011-001 ~ TC-F011-006
"""


class TestHistory:
    """历史单据查询测试"""

    def test_history_all(self, client, mock_db, login_as_requester):
        """TC-F011-001: 查询所有历史单据"""
        resp = client.get('/api/requests/history')
        data = resp.get_json()
        assert resp.status_code == 200
        assert data['success'] is True
        assert 'data' in data
        assert 'total' in data
        assert 'page' in data
        assert data['page'] == 1

    def test_history_filter_by_date(self, client, mock_db, login_as_requester):
        """TC-F011-002: 按日期范围筛选"""
        resp = client.get('/api/requests/history?date_from=2024-05-01&date_to=2024-05-02')
        data = resp.get_json()
        assert resp.status_code == 200
        assert data['success'] is True

    def test_history_filter_by_status(self, client, mock_db, login_as_requester):
        """TC-F011-003: 按状态筛选历史单据"""
        resp = client.get('/api/requests/history?status=rejected')
        data = resp.get_json()
        assert resp.status_code == 200
        assert data['success'] is True

    def test_history_pagination(self, client, mock_db, login_as_requester):
        """TC-F011-004: 分页查询历史单据"""
        resp = client.get('/api/requests/history?page=1&size=1')
        data = resp.get_json()
        assert resp.status_code == 200
        assert data['page'] == 1
        assert data['size'] == 1

    def test_history_page_route(self, client, mock_db, login_as_requester):
        """TC-F011-005: 历史查询页面路由"""
        resp = client.get('/history')
        assert resp.status_code == 200

    def test_history_page_not_logged_in(self, client, mock_db):
        """TC-F011-006: 未登录访问历史页面"""
        resp = client.get('/history')
        # 应该重定向到登录页
        assert resp.status_code == 302
