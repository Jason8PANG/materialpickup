# -*- coding: utf-8 -*-
"""
测试 F-001: LDAP 域账号登录

覆盖 TC-F001-001 ~ TC-F001-010
"""

import json


class TestAuthLogin:
    """LDAP 域账号登录测试"""

    def test_login_success(self, client, mock_db):
        """TC-F001-001: 正确域账号密码登录成功"""
        resp = client.post('/api/auth/login', json={
            'username': 'worker1',
            'password': 'kanban2024'
        })
        data = resp.get_json()
        assert resp.status_code == 200
        assert data['success'] is True
        assert data['user']['username'] == 'worker1'
        assert data['user']['role'] == 'requester'
        assert data['user']['display_name'] == '领料员李四'

    def test_login_wrong_password(self, client, mock_db):
        """TC-F001-002: 错误密码登录失败"""
        resp = client.post('/api/auth/login', json={
            'username': 'worker1',
            'password': 'wrong_password'
        })
        data = resp.get_json()
        assert resp.status_code == 401
        assert data['success'] is False
        assert '用户名或密码错误' in data['message']

    def test_login_empty_username(self, client, mock_db):
        """TC-F001-003: 用户名为空"""
        resp = client.post('/api/auth/login', json={
            'username': '',
            'password': 'kanban2024'
        })
        data = resp.get_json()
        assert resp.status_code == 400
        assert data['success'] is False
        assert '用户名和密码不能为空' in data['message']

    def test_login_empty_password(self, client, mock_db):
        """TC-F001-004: 密码为空"""
        resp = client.post('/api/auth/login', json={
            'username': 'worker1',
            'password': ''
        })
        data = resp.get_json()
        assert resp.status_code == 400
        assert data['success'] is False
        assert '用户名和密码不能为空' in data['message']

    def test_login_no_role_mapping(self, client, mock_db):
        """TC-F001-005: 无角色映射的用户登录"""
        resp = client.post('/api/auth/login', json={
            'username': 'no_role_user',
            'password': 'kanban2024'
        })
        data = resp.get_json()
        assert resp.status_code == 403
        assert data['success'] is False
        assert '没有系统访问权限' in data['message']

    def test_login_inactive_user(self, client, mock_db):
        """TC-F001-006: 已禁用账号登录"""
        resp = client.post('/api/auth/login', json={
            'username': 'inactive_user',
            'password': 'kanban2024'
        })
        data = resp.get_json()
        assert resp.status_code == 403
        assert data['success'] is False
        assert '没有系统访问权限' in data['message']

    def test_login_empty_json(self, client, mock_db):
        """TC-F001-007: 请求体为空"""
        resp = client.post('/api/auth/login', json={})
        data = resp.get_json()
        assert resp.status_code == 400
        assert data['success'] is False
        assert '请提供登录信息' in data.get('message', '')

    def test_logout(self, client, mock_db):
        """TC-F001-008: 退出登录"""
        # 先登录
        client.post('/api/auth/login', json={
            'username': 'worker1',
            'password': 'kanban2024'
        })
        # 再登出
        resp = client.post('/api/auth/logout')
        data = resp.get_json()
        assert resp.status_code == 200
        assert data['success'] is True

        # 验证 session 已清空
        me_resp = client.get('/api/auth/me')
        assert me_resp.status_code == 401

    def test_me_logged_in(self, client, mock_db, login_as_requester):
        """TC-F001-009: 获取当前登录用户信息"""
        resp = client.get('/api/auth/me')
        data = resp.get_json()
        assert resp.status_code == 200
        assert data['success'] is True
        assert data['user']['username'] == 'worker1'
        assert data['user']['role'] == 'requester'

    def test_me_not_logged_in(self, client, mock_db):
        """TC-F001-010: 未登录获取用户信息"""
        resp = client.get('/api/auth/me')
        data = resp.get_json()
        assert resp.status_code == 401
        assert data['success'] is False
        assert '未登录' in data['message']
