# -*- coding: utf-8 -*-
"""
conftest.py - 物料领取看板系统测试基础设施

提供 Flask 测试客户端、Mock 数据库、Mock LDAP 等公共 fixtures。
通过 monkeypatch 模拟 pymysql 数据库连接和 LDAP 认证，使测试无需真实数据库即可运行。
"""

import sys
import os
import pytest
from unittest.mock import MagicMock, patch
from datetime import datetime
from werkzeug.security import generate_password_hash

# 将项目根目录加入 sys.path
sys.path.insert(0, os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))

# 测试用密码哈希（基于 'kanban2024'）
TEST_PASSWORD_HASH = generate_password_hash('kanban2024')


# ============================================================
# Mock 数据常量
# ============================================================

# 测试用角色映射数据
MOCK_MAPPINGS = {
    'admin': {'id': 1, 'domain_account': 'admin', 'display_name': '管理员',
              'role': 'admin', 'email': 'admin@test.com', 'is_active': 1,
              'password_hash': TEST_PASSWORD_HASH},
    'supervisor1': {'id': 2, 'domain_account': 'supervisor1', 'display_name': '主管张三',
                    'role': 'supervisor', 'email': 'supervisor1@test.com', 'is_active': 1,
                    'password_hash': TEST_PASSWORD_HASH},
    'worker1': {'id': 3, 'domain_account': 'worker1', 'display_name': '领料员李四',
                'role': 'requester', 'email': 'worker1@test.com', 'is_active': 1,
                'password_hash': TEST_PASSWORD_HASH},
    'warehouse1': {'id': 4, 'domain_account': 'warehouse1', 'display_name': '仓管王五',
                   'role': 'warehouse', 'email': 'warehouse1@test.com', 'is_active': 1,
                   'password_hash': TEST_PASSWORD_HASH},
    'inactive_user': {'id': 5, 'domain_account': 'inactive_user', 'display_name': '已禁用用户',
                      'role': 'requester', 'email': '', 'is_active': 0,
                      'password_hash': TEST_PASSWORD_HASH},
    'no_role_user': None,  # 无角色映射的用户
}

# 测试用申请单数据
MOCK_REQUESTS = {
    1: {'id': 1, 'job_order': 'WO-2024-001', 'part_number': 'PN-A001',
        'quantity': 10.00, 'price': 5.50, 'total_amount': 55.00, 'stock_qty': 100.00,
        'replenish_reason': '报废', 'replenish_reason_other': None,
        'requester': 'worker1', 'request_time': datetime(2024, 6, 1, 9, 0, 0),
        'status': 'pending_approval', 'supervisor': None,
        'approve_time': None, 'approve_comment': None,
        'warehouse_operator': None, 'short_reason': None, 'short_time': None,
        'signer': None, 'sign_time': None, 'remark': None,
        'is_deleted': 0, 'created_at': datetime(2024, 6, 1, 9, 0, 0),
        'updated_at': datetime(2024, 6, 1, 9, 0, 0)},
    2: {'id': 2, 'job_order': 'WO-2024-002', 'part_number': 'PN-A002',
        'quantity': 20.00, 'price': 3.00, 'total_amount': 60.00, 'stock_qty': 50.00,
        'replenish_reason': '不良', 'replenish_reason_other': None,
        'requester': 'worker1', 'request_time': datetime(2024, 6, 1, 10, 0, 0),
        'status': 'pending_prep', 'supervisor': 'supervisor1',
        'approve_time': datetime(2024, 6, 1, 10, 30, 0), 'approve_comment': '同意',
        'warehouse_operator': None, 'short_reason': None, 'short_time': None,
        'signer': None, 'sign_time': None, 'remark': None,
        'is_deleted': 0, 'created_at': datetime(2024, 6, 1, 10, 0, 0),
        'updated_at': datetime(2024, 6, 1, 10, 30, 0)},
    3: {'id': 3, 'job_order': 'WO-2024-003', 'part_number': 'PN-A003',
        'quantity': 5.00, 'price': 100.00, 'total_amount': 500.00, 'stock_qty': 200.00,
        'replenish_reason': '来料不足', 'replenish_reason_other': None,
        'requester': 'worker1', 'request_time': datetime(2024, 6, 2, 9, 0, 0),
        'status': 'prepping', 'supervisor': 'supervisor1',
        'approve_time': datetime(2024, 6, 2, 9, 30, 0), 'approve_comment': '同意',
        'warehouse_operator': 'warehouse1', 'short_reason': None, 'short_time': None,
        'signer': None, 'sign_time': None, 'remark': None,
        'is_deleted': 0, 'created_at': datetime(2024, 6, 2, 9, 0, 0),
        'updated_at': datetime(2024, 6, 2, 10, 0, 0)},
    4: {'id': 4, 'job_order': 'WO-2024-004', 'part_number': 'PN-A004',
        'quantity': 3.00, 'price': 200.00, 'total_amount': 600.00, 'stock_qty': 0.00,
        'replenish_reason': '报废', 'replenish_reason_other': None,
        'requester': 'worker2', 'request_time': datetime(2024, 6, 3, 9, 0, 0),
        'status': 'short', 'supervisor': 'supervisor1',
        'approve_time': datetime(2024, 6, 3, 9, 30, 0), 'approve_comment': '同意',
        'warehouse_operator': 'warehouse1', 'short_reason': '库存不足',
        'short_time': datetime(2024, 6, 3, 10, 0, 0),
        'signer': None, 'sign_time': None, 'remark': None,
        'is_deleted': 0, 'created_at': datetime(2024, 6, 3, 9, 0, 0),
        'updated_at': datetime(2024, 6, 3, 10, 0, 0)},
    5: {'id': 5, 'job_order': 'WO-2024-005', 'part_number': 'PN-A005',
        'quantity': 8.00, 'price': 12.50, 'total_amount': 100.00, 'stock_qty': 30.00,
        'replenish_reason': '其他', 'replenish_reason_other': '紧急补料',
        'requester': 'worker1', 'request_time': datetime(2024, 6, 4, 9, 0, 0),
        'status': 'ready_pickup', 'supervisor': 'supervisor1',
        'approve_time': datetime(2024, 6, 4, 9, 30, 0), 'approve_comment': '同意',
        'warehouse_operator': 'warehouse1', 'short_reason': None, 'short_time': None,
        'signer': None, 'sign_time': None, 'remark': None,
        'is_deleted': 0, 'created_at': datetime(2024, 6, 4, 9, 0, 0),
        'updated_at': datetime(2024, 6, 4, 10, 0, 0)},
    6: {'id': 6, 'job_order': 'WO-2024-HIST-01', 'part_number': 'PN-H001',
        'quantity': 15.00, 'price': 8.00, 'total_amount': 120.00, 'stock_qty': 0.00,
        'replenish_reason': '报废', 'replenish_reason_other': None,
        'requester': 'worker1', 'request_time': datetime(2024, 5, 1, 9, 0, 0),
        'status': 'completed', 'supervisor': 'supervisor1',
        'approve_time': datetime(2024, 5, 1, 10, 0, 0), 'approve_comment': '同意',
        'warehouse_operator': 'warehouse1', 'short_reason': None, 'short_time': None,
        'signer': 'worker1', 'sign_time': datetime(2024, 5, 1, 11, 0, 0),
        'remark': None, 'is_deleted': 0,
        'created_at': datetime(2024, 5, 1, 9, 0, 0),
        'updated_at': datetime(2024, 5, 1, 11, 0, 0)},
    7: {'id': 7, 'job_order': 'WO-2024-HIST-02', 'part_number': 'PN-H002',
        'quantity': 2.00, 'price': 500.00, 'total_amount': 1000.00, 'stock_qty': 10.00,
        'replenish_reason': '不良', 'replenish_reason_other': None,
        'requester': 'worker2', 'request_time': datetime(2024, 5, 2, 9, 0, 0),
        'status': 'rejected', 'supervisor': 'supervisor1',
        'approve_time': datetime(2024, 5, 2, 9, 30, 0), 'approve_comment': '库存充足，无需补料',
        'warehouse_operator': None, 'short_reason': None, 'short_time': None,
        'signer': None, 'sign_time': None, 'remark': None,
        'is_deleted': 0, 'created_at': datetime(2024, 5, 2, 9, 0, 0),
        'updated_at': datetime(2024, 5, 2, 9, 30, 0)},
    8: {'id': 8, 'job_order': 'WO-2024-DEL', 'part_number': 'PN-DEL',
        'quantity': 1.00, 'price': 10.00, 'total_amount': 10.00, 'stock_qty': 0.00,
        'replenish_reason': '报废', 'replenish_reason_other': None,
        'requester': 'worker1', 'request_time': datetime(2024, 5, 3, 9, 0, 0),
        'status': 'pending_approval', 'supervisor': None,
        'approve_time': None, 'approve_comment': None,
        'warehouse_operator': None, 'short_reason': None, 'short_time': None,
        'signer': None, 'sign_time': None, 'remark': None,
        'is_deleted': 1, 'created_at': datetime(2024, 5, 3, 9, 0, 0),
        'updated_at': datetime(2024, 5, 3, 9, 0, 0)},
}

# Mock 操作日志
MOCK_LOGS = [
    {'id': 1, 'request_id': 1, 'operator': 'worker1', 'action': 'SUBMIT',
     'detail': '提交领料申请: PN-A001 x 10', 'ip_address': '127.0.0.1',
     'created_at': datetime(2024, 6, 1, 9, 0, 0)},
    {'id': 2, 'request_id': 2, 'operator': 'worker1', 'action': 'SUBMIT',
     'detail': '提交领料申请: PN-A002 x 20', 'ip_address': '127.0.0.1',
     'created_at': datetime(2024, 6, 1, 10, 0, 0)},
    {'id': 3, 'request_id': 2, 'operator': 'supervisor1', 'action': 'APPROVE',
     'detail': '审批通过: 同意', 'ip_address': '127.0.0.1',
     'created_at': datetime(2024, 6, 1, 10, 30, 0)},
]

# Mock 审批令牌
MOCK_TOKENS = {
    'valid-token-123': {'id': 1, 'request_id': 1, 'token': 'valid-token-123',
                        'supervisor': 'supervisor1', 'is_used': 0,
                        'expires_at': datetime(2027, 12, 31, 23, 59, 59),
                        'created_at': datetime(2024, 6, 1, 9, 0, 0)},
}

# 请求 ID 自增计数器
request_id_counter = [100]


# ============================================================
# Mock Cursor
# ============================================================

class MockCursor:
    """模拟 pymysql 游标"""

    def __init__(self):
        self._rows = []
        self._row_index = 0
        self.lastrowid = None
        self._sql_log = []
        self._inserted_data = {}

    def execute(self, sql, params=None):
        self._sql_log.append((sql, params))
        sql_upper = sql.upper().strip()
        sql_lower = sql.lower().strip()

        # INSERT
        if sql_upper.startswith('INSERT'):
            request_id_counter[0] += 1
            self.lastrowid = request_id_counter[0]
            self._inserted_data['last_insert'] = params
            return 1

        # SELECT COUNT(*)
        if sql_upper.startswith('SELECT COUNT(*)'):
            # 简单模拟：返回匹配的记录数
            self._rows = [{'total': 1}]
            self._row_index = 0
            return 1

        # 查找角色映射
        if 'kr_role_mapping' in sql and sql_upper.startswith('SELECT'):
            if params:
                param = params[0]
                # 按 ID 查询 (int)
                if isinstance(param, (int, float)):
                    param_int = int(param)
                    for v in MOCK_MAPPINGS.values():
                        if v and v.get('id') == param_int:
                            self._rows = [dict(v)]
                            break
                    else:
                        self._rows = []
                # 按 domain_account 查询 (str)
                else:
                    mapping = MOCK_MAPPINGS.get(param)
                    if mapping and mapping.get('is_active'):
                        self._rows = [dict(mapping)]
                    else:
                        self._rows = []
            else:
                self._rows = [dict(v) for v in MOCK_MAPPINGS.values() if v]
            self._row_index = 0
            return len(self._rows)

        # 查找申请单 (kr_material_request)
        if 'kr_material_request' in sql and sql_upper.startswith('SELECT') and 'COUNT' not in sql_upper:
            if sql_lower.startswith('select t.*, r.'):
                # 联合查询令牌和申请单
                token_val = params[0] if params else None
                token = MOCK_TOKENS.get(token_val)
                if token and token['is_used'] == 0 and token['expires_at'] > datetime.now():
                    req = MOCK_REQUESTS.get(token['request_id'])
                    if req:
                        result = dict(token)
                        result.update(dict(req))
                        result['req_status'] = req['status']
                        self._rows = [result]
                    else:
                        self._rows = []
                else:
                    self._rows = []
                self._row_index = 0
                return len(self._rows)

            if 'WHERE id =' in sql or 'WHERE t.token =' in sql:
                # 按 ID 查询，判断是否是 token 查询
                if 'kr_approval_token' in sql and 't.token =' in sql_lower:
                    # 令牌查询
                    token_val = params[0] if params else None
                    token = MOCK_TOKENS.get(token_val)
                    if token and token['is_used'] == 0 and token['expires_at'] > datetime.now():
                        req = MOCK_REQUESTS.get(token['request_id'])
                        if req:
                            result = dict(req)
                            result['status_label'] = self._get_status_label(req['status'])
                            self._rows = [result]
                        else:
                            self._rows = []
                    else:
                        self._rows = []
                else:
                    # 普通申请单查询
                    rid = params[0] if params else None
                    if isinstance(rid, (int, float)):
                        rid = int(rid)
                    req = MOCK_REQUESTS.get(rid)
                    if req and not req.get('is_deleted', 0):
                        self._rows = [dict(req)]
                    else:
                        # 尝试从 params 中提取
                        self._rows = []
            else:
                # 列表查询 - 过滤未删除且符合状态条件的
                all_reqs = [dict(v) for v in MOCK_REQUESTS.values()
                           if not v.get('is_deleted', 0)]
                self._rows = all_reqs
            self._row_index = 0
            return len(self._rows)

        # 令牌表查询
        if 'kr_approval_token' in sql and sql_upper.startswith('SELECT'):
            self._rows = [dict(v) for v in MOCK_TOKENS.values()]
            self._row_index = 0
            return len(self._rows)

        # UPDATE - 直接成功
        if sql_upper.startswith('UPDATE'):
            return 1

        # DELETE
        if sql_upper.startswith('DELETE'):
            return 1

        # 操作日志查询
        if 'kr_operation_log' in sql and 'COUNT' not in sql_upper:
            self._rows = [dict(l) for l in MOCK_LOGS]
            self._row_index = 0
            return len(self._rows)

        # 默认返回空
        self._rows = []
        self._row_index = 0
        return 0

    def fetchone(self):
        if self._row_index < len(self._rows):
            row = self._rows[self._row_index]
            self._row_index += 1
            return row
        return None

    def fetchall(self):
        rows = self._rows
        self._row_index = len(self._rows)
        return rows

    def close(self):
        pass

    def _get_status_label(self, status):
        labels = {
            'pending_approval': '待审批', 'rejected': '已驳回',
            'pending_prep': '待备料', 'prepping': '备料中',
            'short': '缺料', 'ready_pickup': '待取料', 'completed': '已完成'
        }
        return labels.get(status, status)


class MockDB:
    """模拟数据库连接"""

    def __init__(self):
        self.cursor_obj = MockCursor()

    def cursor(self):
        return self.cursor_obj

    def commit(self):
        pass

    def rollback(self):
        pass

    def close(self):
        pass


# ============================================================
# Fixtures
# ============================================================

@pytest.fixture
def app():
    """创建 Flask 测试应用"""
    from app import create_app
    app = create_app()
    app.config.update({
        'TESTING': True,
        'SECRET_KEY': 'test-secret-key',
        'SERVER_NAME': 'localhost:5000',
    })
    return app


@pytest.fixture
def client(app):
    """Flask 测试客户端"""
    return app.test_client()


@pytest.fixture(autouse=True)
def mock_db(monkeypatch):
    """Mock 数据库连接 - 直接 monkeypatch pymysql.connect"""
    mock_db_instance = MockDB()
    
    def _mock_connect(*args, **kwargs):
        # 每次调用返回新的 MockDB 实例，但保留内部状态
        return mock_db_instance
    
    monkeypatch.setattr('pymysql.connect', _mock_connect)
    return mock_db_instance


@pytest.fixture
def auth_headers(client):
    """登录辅助函数 - 返回登录后的 session"""

    def _login(username):
        with client.session_transaction() as sess:
            mapping = MOCK_MAPPINGS.get(username)
            if mapping and mapping.get('is_active', 1):
                sess['user'] = {
                    'username': mapping['domain_account'],
                    'display_name': mapping['display_name'],
                    'role': mapping['role'],
                    'email': mapping['email']
                }
                sess.permanent = True
        return client

    return _login


@pytest.fixture
def login_as_supervisor(client, auth_headers):
    """以主管身份登录"""
    return auth_headers('supervisor1')


@pytest.fixture
def login_as_requester(client, auth_headers):
    """以领料员身份登录"""
    return auth_headers('worker1')


@pytest.fixture
def login_as_warehouse(client, auth_headers):
    """以仓库人员身份登录"""
    return auth_headers('warehouse1')


@pytest.fixture
def login_as_admin(client, auth_headers):
    """以管理员身份登录"""
    return auth_headers('admin')
