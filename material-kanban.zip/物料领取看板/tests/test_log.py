# -*- coding: utf-8 -*-
"""
测试 F-015: 操作日志审计

覆盖 TC-F015-001 ~ TC-F015-006
"""


class TestOperationLog:
    """操作日志审计测试"""

    def test_logs_all(self, client, mock_db, login_as_requester):
        """TC-F015-001: 查询所有操作日志"""
        resp = client.get('/api/logs')
        data = resp.get_json()
        assert resp.status_code == 200
        assert data['success'] is True
        assert 'data' in data
        assert 'total' in data

    def test_logs_filter_by_request_id(self, client, mock_db, login_as_requester):
        """TC-F015-002: 按 request_id 筛选日志"""
        resp = client.get('/api/logs?request_id=2')
        data = resp.get_json()
        assert resp.status_code == 200
        assert data['success'] is True

    def test_logs_filter_by_action(self, client, mock_db, login_as_requester):
        """TC-F015-003: 按操作类型筛选日志"""
        resp = client.get('/api/logs?action=SUBMIT')
        data = resp.get_json()
        assert resp.status_code == 200
        assert data['success'] is True

    def test_logs_filter_by_operator(self, client, mock_db, login_as_requester):
        """TC-F015-004: 按操作人筛选日志"""
        resp = client.get('/api/logs?operator=worker1')
        data = resp.get_json()
        assert resp.status_code == 200
        assert data['success'] is True

    def test_logs_not_logged_in(self, client, mock_db):
        """TC-F015-006: 未登录查询日志"""
        resp = client.get('/api/logs')
        data = resp.get_json()
        assert resp.status_code == 401
        assert data['success'] is False
        assert '未登录' in data['message']
