"""
数据模型 - 直接使用 pymysql 操作数据库，不使用 ORM
"""
from contextlib import contextmanager
import pymysql
from app.config import Config
from pymysql.cursors import DictCursor


def get_db():
    """获取数据库连接"""
    return pymysql.connect(
        host=Config.MYSQL_HOST,
        port=Config.MYSQL_PORT,
        user=Config.MYSQL_USER,
        password=Config.MYSQL_PASSWORD,
        database=Config.MYSQL_DB,
        charset='utf8mb4',
        cursorclass=DictCursor
    )


@contextmanager
def get_db_connection():
    """数据库连接上下文管理器，确保连接自动关闭"""
    conn = get_db()
    try:
        yield conn
    finally:
        conn.close()
