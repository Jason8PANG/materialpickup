"""
邮件服务 - SMTP 方式发送邮件
"""
import smtplib
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
from email.header import Header
from app.config import Config


def send_email(to_email, subject, html_content):
    """发送邮件"""
    if not Config.SMTP_USER or not Config.SMTP_PASSWORD:
        print(f"[邮件] SMTP 未配置，跳过发送: {subject} -> {to_email}")
        print(f"[邮件] 内容预览: {html_content[:200]}...")
        return False

    try:
        msg = MIMEMultipart('alternative')
        msg['From'] = f"{Header(Config.MAIL_FROM_NAME, 'utf-8').encode()} <{Config.MAIL_FROM}>"
        msg['To'] = to_email
        msg['Subject'] = Header(subject, 'utf-8').encode()

        part = MIMEText(html_content, 'html', 'utf-8')
        msg.attach(part)

        server = smtplib.SMTP(Config.SMTP_SERVER, Config.SMTP_PORT)
        if Config.SMTP_USE_TLS:
            server.starttls()
        server.login(Config.SMTP_USER, Config.SMTP_PASSWORD)
        server.sendmail(Config.MAIL_FROM, [to_email], msg.as_string())
        server.quit()

        print(f"[邮件] 发送成功: {subject} -> {to_email}")
        return True
    except Exception as e:
        print(f"[邮件] 发送失败: {e}")
        return False


def send_approval_email(request_info, approve_url, reject_url):
    """
    发送审批通知邮件
    
    Args:
        request_info: dict, 包含工单号、物料号、数量等信息
        approve_url: str, 审批通过链接
        reject_url: str, 审批驳回链接（带预填驳回意见）
    """
    subject = f"【领料审批】工单 {request_info['job_order']} - {request_info['part_number']}"
    
    html = f"""
    <div style="max-width:600px;margin:0 auto;font-family:Arial,sans-serif;padding:20px;background:#f7f8fa;">
        <div style="background:#409eff;color:#fff;padding:20px;border-radius:8px 8px 0 0;text-align:center;">
            <h2 style="margin:0;">物料领料审批通知</h2>
        </div>
        <div style="background:#fff;padding:20px;border-radius:0 0 8px 8px;">
            <p>您好，有一笔新的领料申请需要您的审批：</p>
            <table style="width:100%;border-collapse:collapse;margin:16px 0;">
                <tr><td style="padding:8px;border:1px solid #e8e8e8;font-weight:bold;width:100px;">工单号</td>
                    <td style="padding:8px;border:1px solid #e8e8e8;">{request_info['job_order']}</td></tr>
                <tr><td style="padding:8px;border:1px solid #e8e8e8;font-weight:bold;">物料号</td>
                    <td style="padding:8px;border:1px solid #e8e8e8;">{request_info['part_number']}</td></tr>
                <tr><td style="padding:8px;border:1px solid #e8e8e8;font-weight:bold;">数量</td>
                    <td style="padding:8px;border:1px solid #e8e8e8;">{request_info['quantity']}</td></tr>
                <tr><td style="padding:8px;border:1px solid #e8e8e8;font-weight:bold;">申请员</td>
                    <td style="padding:8px;border:1px solid #e8e8e8;">{request_info['requester']}</td></tr>
                <tr><td style="padding:8px;border:1px solid #e8e8e8;font-weight:bold;">补料原因</td>
                    <td style="padding:8px;border:1px solid #e8e8e8;">{request_info.get('replenish_reason', '-')}</td></tr>
            </table>
            <div style="text-align:center;margin:24px 0;">
                <a href="{approve_url}" style="display:inline-block;background:#67c23a;color:#fff;padding:12px 32px;border-radius:4px;text-decoration:none;font-size:16px;margin:0 8px;">批准通过</a>
                <a href="{reject_url}" style="display:inline-block;background:#f56c6c;color:#fff;padding:12px 32px;border-radius:4px;text-decoration:none;font-size:16px;margin:0 8px;">驳回</a>
            </div>
            <p style="color:#999;font-size:12px;text-align:center;">此链接72小时内有效，请及时处理</p>
        </div>
    </div>
    """
    
    return send_email(request_info.get('supervisor_email', ''), subject, html)
