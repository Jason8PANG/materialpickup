from flask import Blueprint, request, jsonify, session
from datetime import datetime
from app.models import get_db_connection
from app.utils import WhereBuilder
from app.config import Config
from app.routes.approval import generate_approval_token
from app.services.email_service import send_approval_email

request_bp = Blueprint('request_bp', __name__)


@request_bp.route('/api/requests', methods=['POST'])
def create_request():
    user = session.get('user')
    if not user:
        return jsonify({'success': False, 'message': '未登录'}), 401
    if user['role'] not in ('requester', 'admin'):
        return jsonify({'success': False, 'message': '权限不足'}), 403

    data = request.get_json()
    required = ['job_order', 'part_number', 'quantity']
    for field in required:
        if not data.get(field):
            return jsonify({'success': False, 'message': f'缺少必填字段: {field}'}), 400

    with get_db_connection() as db:
        cursor = db.cursor()
        now = datetime.now()

        cursor.execute(
            """INSERT INTO kr_material_request 
            (job_order, part_number, quantity, price, total_amount, stock_qty, 
             replenish_reason, replenish_reason_other, requester, request_time, status)
            VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, 'pending_approval')""",
            (
                data['job_order'].strip(),
                data['part_number'].strip(),
                float(data['quantity']),
                float(data['price']) if data.get('price') else None,
                float(data['total_amount']) if data.get('total_amount') else None,
                float(data['stock_qty']) if data.get('stock_qty') else None,
                data.get('replenish_reason'),
                data.get('replenish_reason_other'),
                user['username'],
                now
            )
        )
        request_id = cursor.lastrowid

        # 记录日志
        cursor.execute(
            "INSERT INTO kr_operation_log (request_id, operator, action, detail, ip_address, created_at) "
            "VALUES (%s, %s, 'SUBMIT', %s, %s, %s)",
            (request_id, user['username'], f"提交领料申请: {data['part_number']} x {data['quantity']}",
             request.remote_addr, now)
        )
        db.commit()
        cursor.close()

    # 提交成功后查询主管并发送审批邮件
    try:
        with get_db_connection() as db:
            cursor = db.cursor()
            cursor.execute(
                "SELECT domain_account, email FROM kr_role_mapping "
                "WHERE role = 'supervisor' AND is_active = 1 AND email IS NOT NULL AND email != ''"
            )
            supervisors = cursor.fetchall()
            cursor.close()

        for sup in supervisors:
            token = generate_approval_token(request_id, sup['domain_account'])
            request_info = {
                'job_order': data['job_order'],
                'part_number': data['part_number'],
                'quantity': data['quantity'],
                'requester': user['username'],
                'replenish_reason': data.get('replenish_reason', ''),
                'supervisor_email': sup['email']
            }
            approve_url = f"{Config.BASE_URL}/approve/{token}"
            reject_url = f"{Config.BASE_URL}/approve/{token}?action=reject"
            send_approval_email(request_info, approve_url, reject_url)
    except Exception as e:
        print(f"[邮件发送异常] {e}")

    return jsonify({'success': True, 'id': request_id, 'message': '申请提交成功'})


@request_bp.route('/api/requests/<int:request_id>', methods=['GET'])
def get_request(request_id):
    user = session.get('user')
    if not user:
        return jsonify({'success': False, 'message': '未登录'}), 401

    with get_db_connection() as db:
        cursor = db.cursor()
        cursor.execute(
            "SELECT * FROM kr_material_request WHERE id = %s AND is_deleted = 0",
            (request_id,)
        )
        row = cursor.fetchone()
        if not row:
            cursor.close()
            return jsonify({'success': False, 'message': '单据不存在'}), 404

        # 获取操作日志
        cursor.execute(
            "SELECT * FROM kr_operation_log WHERE request_id = %s ORDER BY created_at",
            (request_id,)
        )
        logs = cursor.fetchall()
        cursor.close()

    STATUS_LABELS = {
        'pending_approval': '待审批', 'rejected': '已驳回',
        'pending_prep': '待备料', 'prepping': '备料中',
        'short': '缺料', 'ready_pickup': '待取料', 'completed': '已完成'
    }
    result = dict(row)
    result['status_label'] = STATUS_LABELS.get(row['status'], row['status'])

    return jsonify({'success': True, 'request': result, 'logs': logs})


@request_bp.route('/api/requests', methods=['GET'])
def list_requests():
    user = session.get('user')
    if not user:
        return jsonify({'success': False, 'message': '未登录'}), 401

    status = request.args.get('status')
    job_order = request.args.get('job_order')
    part_number = request.args.get('part_number')
    page = int(request.args.get('page', 1))
    size = int(request.args.get('size', 20))

    wb = WhereBuilder(["is_deleted = 0"])

    if status:
        wb.add("status = %s", status)
    if job_order:
        wb.add("job_order LIKE %s", f"%{job_order}%")
    if part_number:
        wb.add("part_number LIKE %s", f"%{part_number}%")

    where_clause, params = wb.build()

    with get_db_connection() as db:
        cursor = db.cursor()

        # 总数
        cursor.execute(f"SELECT COUNT(*) as total FROM kr_material_request WHERE {where_clause}", params)
        total = cursor.fetchone()['total']

        # 分页
        offset = (page - 1) * size
        cursor.execute(
            f"SELECT * FROM kr_material_request WHERE {where_clause} ORDER BY id DESC LIMIT %s OFFSET %s",
            params + [size, offset]
        )
        rows = cursor.fetchall()
        cursor.close()

    STATUS_LABELS = {
        'pending_approval': '待审批', 'rejected': '已驳回',
        'pending_prep': '待备料', 'prepping': '备料中',
        'short': '缺料', 'ready_pickup': '待取料', 'completed': '已完成'
    }

    result = []
    for row in rows:
        r = dict(row)
        r['status_label'] = STATUS_LABELS.get(row['status'], row['status'])
        result.append(r)

    return jsonify({
        'success': True,
        'data': result,
        'total': total,
        'page': page,
        'size': size,
        'total_pages': (total + size - 1) // size
    })


@request_bp.route('/api/requests/history', methods=['GET'])
def history():
    user = session.get('user')
    if not user:
        return jsonify({'success': False, 'message': '未登录'}), 401

    status = request.args.get('status')
    job_order = request.args.get('job_order')
    part_number = request.args.get('part_number')
    date_from = request.args.get('date_from')
    date_to = request.args.get('date_to')
    page = int(request.args.get('page', 1))
    size = int(request.args.get('size', 20))

    wb = WhereBuilder(["is_deleted = 0"])

    if status:
        wb.add("status = %s", status)
    if job_order:
        wb.add("job_order LIKE %s", f"%{job_order}%")
    if part_number:
        wb.add("part_number LIKE %s", f"%{part_number}%")
    if date_from:
        wb.add("request_time >= %s", date_from)
    if date_to:
        wb.add("request_time <= %s", f"{date_to} 23:59:59")

    # 只查已完成和已驳回
    wb.add("(status = 'completed' OR status = 'rejected')")

    where_clause, params = wb.build()

    with get_db_connection() as db:
        cursor = db.cursor()

        cursor.execute(f"SELECT COUNT(*) as total FROM kr_material_request WHERE {where_clause}", params)
        total = cursor.fetchone()['total']

        offset = (page - 1) * size
        cursor.execute(
            f"SELECT * FROM kr_material_request WHERE {where_clause} ORDER BY id DESC LIMIT %s OFFSET %s",
            params + [size, offset]
        )
        rows = cursor.fetchall()
        cursor.close()

    STATUS_LABELS = {
        'pending_approval': '待审批', 'rejected': '已驳回',
        'pending_prep': '待备料', 'prepping': '备料中',
        'short': '缺料', 'ready_pickup': '待取料', 'completed': '已完成'
    }

    result = []
    for row in rows:
        r = dict(row)
        r['status_label'] = STATUS_LABELS.get(row['status'], row['status'])
        result.append(r)

    return jsonify({
        'success': True,
        'data': result,
        'total': total,
        'page': page,
        'size': size,
        'total_pages': (total + size - 1) // size
    })
