from flask import Blueprint, jsonify, session
from app.models import get_db_connection

kanban_bp = Blueprint('kanban', __name__)

STATUS_LABELS = {
    'pending_approval': '待审批',
    'pending_prep': '待备料',
    'prepping': '备料中',
    'short': '缺料',
    'ready_pickup': '待取料',
    'rejected': '已驳回',
    'completed': '已完成'
}

STATUS_ORDER = [
    'pending_approval',
    'pending_prep',
    'prepping',
    'short',
    'ready_pickup'
]

STATUS_ACTIONS = {
    'pending_approval': [],
    'pending_prep': [],
    'prepping': ['short'],
    'short': [],
    'ready_pickup': ['sign']
}

STATUS_ACTIONS_WAREHOUSE = {
    'pending_approval': [],
    'pending_prep': ['assign_worker', 'start_prep'],
    'prepping': ['complete_prep', 'short'],
    'short': [],
    'ready_pickup': []
}


@kanban_bp.route('/api/kanban/cards', methods=['GET'])
def get_kanban_cards():
    user = session.get('user')
    if not user:
        return jsonify({'success': False, 'message': '未登录'}), 401

    with get_db_connection() as db:
        cursor = db.cursor()

        cursor.execute(
            "SELECT * FROM kr_material_request "
            "WHERE status IN ('pending_approval','pending_prep','prepping','short','ready_pickup') "
            "AND is_deleted = 0 "
            "ORDER BY request_time DESC"
        )
        rows = cursor.fetchall()
        cursor.close()

    # 按状态分组
    groups = {}
    for s in STATUS_ORDER:
        column = []
        for row in rows:
            if row['status'] == s:
                card = dict(row)
                card['status_label'] = STATUS_LABELS.get(s, s)
                # 决定按钮
                if user['role'] == 'warehouse':
                    card['actions'] = STATUS_ACTIONS_WAREHOUSE.get(s, [])
                elif user['role'] == 'supervisor' and s == 'pending_approval':
                    card['actions'] = ['approve', 'reject']
                elif user['role'] == 'requester':
                    card['actions'] = STATUS_ACTIONS.get(s, [])
                elif user['role'] == 'admin':
                    card['actions'] = ['approve', 'reject', 'assign_worker', 'start_prep', 'complete_prep', 'short', 'sign']
                else:
                    card['actions'] = []
                column.append(card)
        groups[s] = {
            'title': STATUS_LABELS.get(s, s),
            'cards': column,
            'count': len(column)
        }

    return jsonify({
        'success': True,
        'groups': groups,
        'status_order': STATUS_ORDER,
        'status_labels': STATUS_LABELS
    })
