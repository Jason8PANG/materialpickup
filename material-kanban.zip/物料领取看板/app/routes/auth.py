from flask import Blueprint, request, jsonify, session
from werkzeug.security import check_password_hash
from app.models import get_db_connection

auth_bp = Blueprint('auth', __name__)


@auth_bp.route('/api/auth/login', methods=['POST'])
def login():
    data = request.get_json()
    if not data:
        return jsonify({'success': False, 'message': '请提供登录信息'}), 400

    username = data.get('username', '').strip()
    password = data.get('password', '').strip()

    if not username or not password:
        return jsonify({'success': False, 'message': '用户名和密码不能为空'}), 400

    # 查询角色映射
    with get_db_connection() as db:
        cursor = db.cursor()
        cursor.execute(
            'SELECT * FROM kr_role_mapping WHERE domain_account = %s AND is_active = 1',
            (username,)
        )
        mapping = cursor.fetchone()
        cursor.close()

    if not mapping:
        return jsonify({'success': False, 'message': '该用户没有系统访问权限，请联系管理员'}), 403

    # 验证密码
    pw_hash = mapping.get('password_hash')
    if pw_hash:
        # 非空密码哈希，使用 werkzeug 验证
        if not check_password_hash(pw_hash, password):
            return jsonify({'success': False, 'message': '用户名或密码错误'}), 401
    else:
        # 密码哈希为空，默认密码等于 domain_account（首次登录强制修改）
        if password != mapping['domain_account']:
            return jsonify({'success': False, 'message': '用户名或密码错误'}), 401

    # 保存会话
    session['user'] = {
        'username': mapping['domain_account'],
        'display_name': mapping['display_name'] or mapping['domain_account'],
        'role': mapping['role'],
        'email': mapping['email']
    }
    session.permanent = True

    return jsonify({
        'success': True,
        'user': session['user']
    })


@auth_bp.route('/api/auth/logout', methods=['POST'])
def logout():
    session.clear()
    return jsonify({'success': True})


@auth_bp.route('/api/auth/me', methods=['GET'])
def me():
    user = session.get('user')
    if not user:
        return jsonify({'success': False, 'message': '未登录'}), 401
    return jsonify({'success': True, 'user': user})
