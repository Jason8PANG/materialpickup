"""
数据库初始化脚本
运行: python -m app.init_db
"""
import sys
import os
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

import pymysql
from app.config import Config


def get_connection():
    return pymysql.connect(
        host=Config.MYSQL_HOST,
        port=Config.MYSQL_PORT,
        user=Config.MYSQL_USER,
        password=Config.MYSQL_PASSWORD,
        database=Config.MYSQL_DB,
        charset='utf8mb4',
        cursorclass=pymysql.cursors.DictCursor
    )


CREATE_TABLES = [
    """
    CREATE TABLE IF NOT EXISTS kr_material_request (
      id INT AUTO_INCREMENT PRIMARY KEY,
      job_order VARCHAR(64) NOT NULL,
      part_number VARCHAR(128) NOT NULL,
      quantity DECIMAL(12,2) NOT NULL,
      price DECIMAL(12,4),
      total_amount DECIMAL(14,2),
      stock_qty DECIMAL(12,2),
      replenish_reason VARCHAR(32),
      replenish_reason_other VARCHAR(256),
      requester VARCHAR(64) NOT NULL,
      request_time DATETIME DEFAULT CURRENT_TIMESTAMP,
      status VARCHAR(20) NOT NULL DEFAULT 'pending_approval',
      supervisor VARCHAR(64),
      approve_time DATETIME,
      approve_comment TEXT,
      warehouse_operator VARCHAR(64),
      short_reason TEXT,
      short_time DATETIME,
      signer VARCHAR(64),
      sign_time DATETIME,
      remark TEXT,
      is_deleted TINYINT(1) DEFAULT 0,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
      INDEX idx_status (status),
      INDEX idx_job_order (job_order),
      INDEX idx_requester (requester)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
    """,
    """
    CREATE TABLE IF NOT EXISTS kr_role_mapping (
      id INT AUTO_INCREMENT PRIMARY KEY,
      domain_account VARCHAR(128) NOT NULL UNIQUE,
      display_name VARCHAR(128),
      role VARCHAR(32) NOT NULL,
      email VARCHAR(256),
      password_hash VARCHAR(256),
      is_active TINYINT(1) DEFAULT 1,
      remark VARCHAR(256),
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
    """,
    """
    CREATE TABLE IF NOT EXISTS kr_approval_token (
      id INT AUTO_INCREMENT PRIMARY KEY,
      request_id INT NOT NULL,
      token VARCHAR(64) NOT NULL UNIQUE,
      supervisor VARCHAR(64) NOT NULL,
      is_used TINYINT(1) DEFAULT 0,
      expires_at DATETIME NOT NULL,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
    """,
    """
    CREATE TABLE IF NOT EXISTS kr_operation_log (
      id BIGINT AUTO_INCREMENT PRIMARY KEY,
      request_id INT,
      operator VARCHAR(64) NOT NULL,
      action VARCHAR(64) NOT NULL,
      detail TEXT,
      ip_address VARCHAR(45),
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
    """
]


SEED_DATA = [
    """
    INSERT IGNORE INTO kr_role_mapping (domain_account, display_name, role, email, is_active, remark)
    VALUES ('admin', '管理员', 'admin', 'admin@example.com', 1, '系统管理员')
    """,
    """
    INSERT IGNORE INTO kr_role_mapping (domain_account, display_name, role, email, is_active, remark)
    VALUES ('supervisor1', '主管张三', 'supervisor', 'supervisor1@example.com', 1, '生产主管')
    """,
    """
    INSERT IGNORE INTO kr_role_mapping (domain_account, display_name, role, email, is_active, remark)
    VALUES ('worker1', '领料员李四', 'requester', 'worker1@example.com', 1, '领料员')
    """,
    """
    INSERT IGNORE INTO kr_role_mapping (domain_account, display_name, role, email, is_active, remark)
    VALUES ('warehouse1', '仓管王五', 'warehouse', 'warehouse1@example.com', 1, '仓库人员')
    """,
    """
    INSERT IGNORE INTO kr_role_mapping (domain_account, display_name, role, email, is_active, remark)
    VALUES ('worker2', '领料员赵六', 'requester', 'worker2@example.com', 1, '领料员')
    """,
    """
    INSERT IGNORE INTO kr_role_mapping (domain_account, display_name, role, email, is_active, remark)
    VALUES ('warehouse2', '仓管陈七', 'warehouse', 'warehouse2@example.com', 1, '仓库人员')
    """
]


def init_database():
    conn = get_connection()
    cursor = conn.cursor()
    print('开始创建数据库表...')
    for sql in CREATE_TABLES:
        table_name = sql.split('TABLE')[2].split()[1].split('(')[0].strip()
        cursor.execute(sql)
        print(f'  [OK] 表 {table_name} 已创建/已存在')
    conn.commit()

    print('开始插入初始数据...')
    for sql in SEED_DATA:
        try:
            cursor.execute(sql)
            conn.commit()
        except Exception as e:
            conn.rollback()
            print(f'  [WARN] 插入数据失败: {e}')
    print('初始数据插入完成!')

    cursor.close()
    conn.close()
    print('数据库初始化完成!')


if __name__ == '__main__':
    init_database()
