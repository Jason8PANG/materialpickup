import os
import secrets


class Config:
    SECRET_KEY = os.environ.get('SECRET_KEY', secrets.token_hex(32))
    
    # MySQL
    MYSQL_HOST = os.environ.get('MYSQL_HOST', '10.0.6.86')
    MYSQL_PORT = int(os.environ.get('MYSQL_PORT', 33306))
    MYSQL_USER = os.environ.get('MYSQL_USER', 'powerbi')
    MYSQL_PASSWORD = os.environ.get('MYSQL_PASSWORD', '')
    MYSQL_DB = os.environ.get('MYSQL_DB', 'materialpickup')
    
    # 连接 URI
    SQLALCHEMY_DATABASE_URI = f'mysql+pymysql://{MYSQL_USER}:{MYSQL_PASSWORD}@{MYSQL_HOST}:{MYSQL_PORT}/{MYSQL_DB}?charset=utf8mb4'
    SQLALCHEMY_TRACK_MODIFICATIONS = False
    
    # Session 安全配置
    SESSION_TYPE = 'filesystem'
    SESSION_COOKIE_HTTPONLY = True
    SESSION_COOKIE_SAMESITE = 'Lax'
    SESSION_PERMANENT = True
    PERMANENT_SESSION_LIFETIME = 28800  # 8小时
    
    # LDAP 配置（预留）
    LDAP_SERVER = os.environ.get('LDAP_SERVER', 'ldap://10.0.0.1:389')
    LDAP_BASE_DN = os.environ.get('LDAP_BASE_DN', 'dc=example,dc=com')
    LDAP_DOMAIN = os.environ.get('LDAP_DOMAIN', 'EXAMPLE')
    
    # SMTP 邮件配置
    SMTP_SERVER = os.environ.get('SMTP_SERVER', 'smtp.example.com')
    SMTP_PORT = int(os.environ.get('SMTP_PORT', 587))
    SMTP_USE_TLS = os.environ.get('SMTP_USE_TLS', 'true').lower() == 'true'
    SMTP_USER = os.environ.get('SMTP_USER', '')
    SMTP_PASSWORD = os.environ.get('SMTP_PASSWORD', '')
    MAIL_FROM = os.environ.get('MAIL_FROM', 'kanban@example.com')
    MAIL_FROM_NAME = os.environ.get('MAIL_FROM_NAME', '物料领取看板系统')
    
    # 系统基础 URL（用于邮件审批链接）
    BASE_URL = os.environ.get('BASE_URL', 'http://localhost:5000')
